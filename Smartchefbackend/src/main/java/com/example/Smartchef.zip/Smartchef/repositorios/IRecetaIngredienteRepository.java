package com.example.Smartchef.repositorios;

import com.example.Smartchef.modelos.RecetaIngredientes;
import com.example.Smartchef.modelos.RecetaIngredienteId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IRecetaIngredienteRepository extends JpaRepository<RecetaIngredientes, RecetaIngredienteId> {

    List<RecetaIngredientes> findById_IdReceta(Integer idReceta);

    List<RecetaIngredientes> findById_IdIngrediente(Integer idIngrediente);
}
