package com.example.Smartchef.servicios;

import com.example.Smartchef.dto.HistorialDTO;
import com.example.Smartchef.modelos.Historial;
import com.example.Smartchef.modelos.Usuario;
import com.example.Smartchef.modelos.Receta;
import com.example.Smartchef.repositorios.IHistorialRepository;
import com.example.Smartchef.repositorios.IRecetaRepository;
import com.example.Smartchef.repositorios.IUsuarioRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class HistorialService {

    private IHistorialRepository historialRepository;
    private IUsuarioRepository usuarioRepository;
    private IRecetaRepository recetaRepository;

    public void registrar(HistorialDTO dto){

        Usuario u = usuarioRepository.findById(dto.getIdUsuario()).orElse(null);
        Receta r = recetaRepository.findById(dto.getIdReceta()).orElse(null);
        if(u == null || r == null) return;

        Historial h = new Historial();
        h.setUsuario(u);    // CORRECTO
        h.setReceta(r);     // CORRECTO
        h.setFecha(dto.getFecha());

        historialRepository.save(h);
    }

    // Obtener historial de la última semana de un usuario
    public List<HistorialDTO> semana(Integer idUsuario){

        LocalDate hoy = LocalDate.now();
        LocalDate inicio = hoy.minusDays(6);

        List<Historial> lista =
                historialRepository.findByUsuarioIdUsuarioAndFechaBetween(idUsuario, inicio, hoy);

        List<HistorialDTO> dtos = new ArrayList<>();

        for(Historial h : lista){
            HistorialDTO dto = new HistorialDTO();
            dto.setIdHistorial(h.getIdHistorial());               // opcional
            dto.setIdUsuario(h.getUsuario().getIdUsuario());      // CORRECTO
            dto.setIdReceta(h.getReceta().getIdReceta());         // CORRECTO
            dto.setFecha(h.getFecha());
            dtos.add(dto);
        }

        return dtos;
    }
}
