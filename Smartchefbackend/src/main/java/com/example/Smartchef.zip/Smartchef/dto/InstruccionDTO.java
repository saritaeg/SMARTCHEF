package com.example.Smartchef.dto;
import lombok.Data;

@Data
public class InstruccionDTO {
    public Integer pasoNumero;
    public String descripcion;
    public String imagenUrl;
}
