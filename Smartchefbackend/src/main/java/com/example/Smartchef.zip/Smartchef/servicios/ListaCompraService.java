package com.example.Smartchef.servicios;

import com.example.Smartchef.dto.IngredienteCantidadDTO;
import com.example.Smartchef.dto.ListaCompraDTO;
import com.example.Smartchef.modelos.*;
import com.example.Smartchef.repositorios.*;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class ListaCompraService {

    private IListaCompraRepository listaRepository;
    private IListaIngredienteRepository listaIngRepository;
    private IRecetaIngredienteRepository recetaIngRepository;
    private IRecetaRepository recetaRepository;

    public ListaCompraDTO generarLista(Integer idUsuario, Integer idReceta){

        Receta receta = recetaRepository.findById(idReceta).orElse(null);
        if(receta == null) return null;

        ListasCompras lc = new ListasCompras();
        Usuario u = new Usuario();
        u.setIdUsuario(idUsuario);
        lc.setUsuario(u);
        lc.setNombre("lista generada");
        lc = listaRepository.save(lc);

        List<RecetaIngredientes> ingredientes = recetaIngRepository.findById_IdReceta(idReceta);


        List<IngredienteCantidadDTO> dtos = new ArrayList<>();

        for(RecetaIngredientes ri : ingredientes){
            ListaIngrediente li = new ListaIngrediente();
            li.setIdLista(lc);
            li.setIdIngrediente(ri.getIngrediente());
            li.setCantidad(ri.getCantidad());
            li.setComprado(false);
            listaIngRepository.save(li);

            IngredienteCantidadDTO i = new IngredienteCantidadDTO();
            i.setNombre(ri.getIngrediente().getNombre());
            i.setCantidad(ri.getCantidad());
            i.setUnidad(ri.getUnidad());
            dtos.add(i);
        }

        ListaCompraDTO out = new ListaCompraDTO();
        out.setIdLista(lc.getIdLista());
        out.setIdUsuario(idUsuario);
        out.setNombre(lc.getNombre());
        out.setIngredientes(dtos);

        return out;
    }
}
