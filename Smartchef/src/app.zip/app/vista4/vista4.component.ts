import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RecetaService, Receta } from '../servicio/receta-service';

@Component({
  selector: 'app-vista4',
  templateUrl: './vista4.component.html',
  styleUrls: ['./vista4.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule]
})
export class Vista4Component implements OnInit {

  private router = inject(Router);
  private recetaService = inject(RecetaService);

  searchQuery: string = '';
  cards: Receta[] = [];

  // FILTROS
  desplegarFiltros: boolean = false;
  filtros = {
    vegetariano: false,
    sinGluten: false,
    rapido: false,
    economico: false
  };
  textoFiltros: string = "Filtros";

  ngOnInit() {
    this.cargarRecetas();
  }

  cargarRecetas() {
    this.recetaService.obtenerRecetas().subscribe({
      next: (data) => this.cards = data,
      error: (err) => console.error('Error al cargar recetas', err)
    });
  }

  buscar() {
    this.recetaService.obtenerRecetas(
      this.searchQuery,
      this.filtros.vegetariano,
      this.filtros.sinGluten,
      this.filtros.rapido,
      this.filtros.economico
    ).subscribe({
      next: (data) => this.cards = data,
      error: (err) => console.error('Error en búsqueda', err)
    });
  }

  toggleDesplegable() {
    this.desplegarFiltros = !this.desplegarFiltros;
  }

  cerrarFiltros() {
    this.desplegarFiltros = false;
  }

  aplicarFiltros() {
    const seleccionados: string[] = [];
    if (this.filtros.vegetariano) seleccionados.push("Vegetariano");
    if (this.filtros.sinGluten) seleccionados.push("Sin gluten");
    if (this.filtros.rapido) seleccionados.push("Rápido");
    if (this.filtros.economico) seleccionados.push("Económico");

    this.textoFiltros = seleccionados.length > 0 ? seleccionados.join(", ") : "Filtros";
    this.desplegarFiltros = false;

    // Aplicar filtros y buscar
    this.buscar();
  }

  // FUNCIONES DE NAV Y CARDS
  toggleFavorito(card: any) { card.favorito = !card.favorito; }
  abrirReceta(card: any) { this.router.navigate(['/vista9'], { state: { receta: card } }); }
  eliminarCard(index: number) { this.cards.splice(index, 1); }
  anadirReceta() { this.router.navigate(['/vista11']); }
  irDescubrir() { this.router.navigate(['/vista4']); }
  irFavoritos() { this.router.navigate(['/vista5']); }
  irCompras() { console.log('/vista6'); }
  irPlanificar() { console.log('/vista8'); }
}
