package com.example.Smartchef.dto;

import com.example.Smartchef.dto.IngredienteCantidadDTO;
import lombok.Data;
import java.util.List;

@Data
public class ListaCompraDTO {
    private Integer idLista;
    private Integer idUsuario;
    private String nombre;
    private List<IngredienteCantidadDTO> ingredientes;
}
