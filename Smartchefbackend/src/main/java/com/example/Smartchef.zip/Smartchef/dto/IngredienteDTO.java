package com.example.Smartchef.dto;

public class IngredienteDTO {
    private String nombre;
    private String categoria; // String
    private String unidadMedida;
}
