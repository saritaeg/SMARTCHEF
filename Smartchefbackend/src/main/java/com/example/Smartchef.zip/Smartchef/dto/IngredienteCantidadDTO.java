package com.example.Smartchef.dto;
import com.example.Smartchef.modelos.Ingrediente;
import lombok.Data;

@Data
public class IngredienteCantidadDTO {
    public String nombre;
    public Double cantidad;
    public String unidad;
    private Ingrediente.Categoria categoria; // enum de Ingrediente

    public Ingrediente.Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Ingrediente.Categoria categoria) {
        this.categoria = categoria;
    }

    // Método extra para enviar como String
    public String getCategoriaString() {
        return (categoria != null) ? categoria.name() : "OTROS";
    }

}
