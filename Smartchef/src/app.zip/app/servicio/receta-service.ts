import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Receta {
  idReceta: number;
  nombre: string;
  descripcion: string;
  tiempoPreparacion: number;
  vegetariano: boolean;
  sinGluten: boolean;
  rapido: boolean;
  economico: boolean;
  fotoUrl: string;
}

@Injectable({
  providedIn: 'root'
})
export class RecetaService {

  private baseUrl = 'http://localhost:8080/api/recetas';

  constructor(private http: HttpClient) { }

  obtenerRecetas(
    ingrediente?: string,
    vegetariano?: boolean,
    sinGluten?: boolean,
    rapido?: boolean,
    economico?: boolean
  ): Observable<Receta[]> {
    let params = new HttpParams();
    if (ingrediente) params = params.set('ingrediente', ingrediente);
    if (vegetariano !== undefined) params = params.set('vegetariano', vegetariano);
    if (sinGluten !== undefined) params = params.set('sinGluten', sinGluten);
    if (rapido !== undefined) params = params.set('rapido', rapido);
    if (economico !== undefined) params = params.set('economico', economico);

    return this.http.get<Receta[]>(this.baseUrl, { params });
  }
}
