package com.example.Smartchef.controladores;

import com.example.Smartchef.modelos.Receta;
import com.example.Smartchef.servicios.RecetaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recetas")
public class RecetaController {

    private final RecetaService recetaService;

    public RecetaController(RecetaService recetaService) {
        this.recetaService = recetaService;
    }

    // Listar todas las recetas
    @GetMapping
    public List<Receta> getTodasRecetas() {
        return recetaService.getTodasRecetas();
    }

    // Buscar por nombre
    @GetMapping("/buscar")
    public List<Receta> buscarPorNombre(@RequestParam String nombre) {
        return recetaService.buscarPorNombre(nombre);
    }

    // Buscar por ingrediente
    @GetMapping("/ingrediente")
    public List<Receta> buscarPorIngrediente(@RequestParam String nombre) {
        return recetaService.buscarPorIngrediente(nombre);
    }

    // Filtrar recetas por booleanos
    @GetMapping("/filtros")
    public List<Receta> filtrarRecetas(
            @RequestParam(required = false) Boolean vegetariano,
            @RequestParam(required = false) Boolean sinGluten,
            @RequestParam(required = false) Boolean rapido,
            @RequestParam(required = false) Boolean economico
    ) {
        return recetaService.buscarPorFiltros(vegetariano, sinGluten, rapido, economico);
    }

    // Guardar receta
    @PostMapping
    public Receta guardarReceta(@RequestBody Receta receta) {
        return recetaService.guardarReceta(receta);
    }

    // Eliminar receta
    @DeleteMapping("/{idReceta}")
    public void eliminarReceta(@PathVariable Integer idReceta) {
        recetaService.eliminarReceta(idReceta);
    }
}
