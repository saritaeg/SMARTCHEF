package com.example.Smartchef.servicios;

import com.example.Smartchef.modelos.Receta;
import com.example.Smartchef.repositorios.IRecetaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecetaService {

    private final IRecetaRepository recetaRepository;

    public RecetaService(IRecetaRepository recetaRepository) {
        this.recetaRepository = recetaRepository;
    }

    // Obtener todas las recetas
    public List<Receta> getTodasRecetas() {
        return recetaRepository.findAll();
    }

    // Buscar recetas por filtros
    public List<Receta> buscarPorFiltros(Boolean vegetariano, Boolean sinGluten, Boolean rapido, Boolean economico) {
        return recetaRepository.findByFiltros(vegetariano, sinGluten, rapido, economico);
    }

    // Buscar por nombre de receta
    public List<Receta> buscarPorNombre(String nombre) {
        return recetaRepository.findByNombreContainingIgnoreCase(nombre);
    }

    // Buscar por nombre de ingrediente
    public List<Receta> buscarPorIngrediente(String nombreIngrediente) {
        return recetaRepository.findByIngredienteNombre(nombreIngrediente);
    }

    // Buscar recetas por usuario
    public List<Receta> getRecetasPorUsuario(Integer idUsuario) {
        return recetaRepository.findByUsuario_IdUsuario(idUsuario);
    }

    // Guardar o actualizar receta
    public Receta guardarReceta(Receta receta) {
        return recetaRepository.save(receta);
    }

    // Eliminar receta
    public void eliminarReceta(Integer idReceta) {
        recetaRepository.deleteById(idReceta);
    }
}
