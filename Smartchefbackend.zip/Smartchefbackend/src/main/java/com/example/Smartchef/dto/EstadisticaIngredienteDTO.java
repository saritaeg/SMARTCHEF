package com.example.Smartchef.dto;
import lombok.Data;

@Data
public class EstadisticaIngredienteDTO {
    public String nombreIngrediente;
    public Long usos;
}
