package com.example.Smartchef.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class HistorialDTO {
    private Integer idHistorial; // opcional si quieres el id del historial
    private Integer idUsuario;
    private Integer idReceta;
    private LocalDate fecha;
}
