package com.example.Smartchef.controladores;

import com.example.Smartchef.dto.HistorialDTO;
import com.example.Smartchef.servicios.HistorialService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/historial-cocina")
public class HistorialController {

    private HistorialService service;

    @PostMapping
    public ResponseEntity<?> registrar(@RequestBody HistorialDTO dto){
        service.registrar(dto);
        return ResponseEntity.ok("Registrado");
    }

    @GetMapping
    public ResponseEntity<?> semana(@RequestParam Integer idUsuario){
        return ResponseEntity.ok(service.semana(idUsuario));
    }
}
