package com.example.Smartchef.repositorios;

import com.example.Smartchef.modelos.Favorito;
import com.example.Smartchef.modelos.FavoritoId;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface IFavoritoRepository extends JpaRepository<Favorito, FavoritoId> {

    // Buscar todos los favoritos de un usuario
    List<Favorito> findByIdIdUsuario(Integer idUsuario);

    // Buscar todos los favoritos de una receta
    List<Favorito> findByIdIdReceta(Integer idReceta);
}
