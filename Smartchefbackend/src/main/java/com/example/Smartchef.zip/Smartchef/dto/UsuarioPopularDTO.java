package com.example.Smartchef.dto;

import lombok.Data;

@Data
public class UsuarioPopularDTO {
    public Integer idUsuario;
    public String nombre;
    public Long vecesGuardado;
}
