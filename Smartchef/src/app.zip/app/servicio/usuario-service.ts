import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  private API_URL = 'http://localhost:8080';
  private http = inject(HttpClient);

  // Login con debug
  login(email: string, contrasena: string): Observable<any> {
    const body = {
      email: email.trim().toLowerCase(),
      contrasenia: contrasena.trim() // ⚠️ Debe coincidir con DTO del backend
    };
    console.log('Enviando login:', body); // <-- muestra lo que se envía
    return this.http.post(`${this.API_URL}/usuarios/login`, body).pipe(
      tap({
        next: (res) => console.log('Respuesta backend:', res),
        error: (err) => console.error('Error backend:', err)
      })
    );
  }

  crearUsuario(usuario: any): Observable<any> {
    return this.http.post(`${this.API_URL}/usuarios/crear`, usuario);
  }
}
