package com.example.Smartchef.repositorios;

import com.example.Smartchef.modelos.InstruccionReceta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IInstruccionRepository extends JpaRepository<InstruccionReceta, Integer> {
    List<InstruccionReceta> findByRecetaIdRecetaOrderByPasoNumeroAsc(Integer idReceta);
}
