package com.example.Smartchef.controladores;

import com.example.Smartchef.servicios.EstadisticaService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/estadisticas")
public class EstadisticaController {

    private EstadisticaService service;

    @GetMapping("/ingredientes")
    public ResponseEntity<?> topIngredientes(){
        return ResponseEntity.ok(service.topIngredientes());
    }

    @GetMapping("/usuarioPopular")
    public ResponseEntity<?> usuarioPopular(){
        return ResponseEntity.ok(service.usuarioPopular());
    }
}
