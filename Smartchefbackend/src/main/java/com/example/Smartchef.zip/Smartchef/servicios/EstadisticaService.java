package com.example.Smartchef.servicios;

import com.example.Smartchef.dto.EstadisticaIngredienteDTO;
import com.example.Smartchef.dto.UsuarioPopularDTO;
import com.example.Smartchef.modelos.Favorito;
import com.example.Smartchef.modelos.Receta;
import com.example.Smartchef.modelos.RecetaIngredientes;
import com.example.Smartchef.repositorios.IFavoritoRepository;
import com.example.Smartchef.repositorios.IRecetaRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
@AllArgsConstructor
public class EstadisticaService {

    private IFavoritoRepository favoritoRepository;
    private IRecetaRepository recetaRepository;

    // Top 5 ingredientes más usados
    public List<EstadisticaIngredienteDTO> topIngredientes(){
        Map<String, Long> contador = new HashMap<>();

        List<Receta> recetas = recetaRepository.findAll();

        for(Receta r : recetas){
            r.getRecetaIngredientes().forEach(ri -> {
                String nombre = ri.getIngrediente().getNombre();
                contador.put(nombre, contador.getOrDefault(nombre, 0L) + 1L);
            });
        }

        List<EstadisticaIngredienteDTO> lista = new ArrayList<>();

        contador.entrySet().stream()
                .sorted((a,b)->Long.compare(b.getValue(), a.getValue()))
                .limit(5)
                .forEach(e->{
                    EstadisticaIngredienteDTO dto = new EstadisticaIngredienteDTO();
                    dto.setNombreIngrediente(e.getKey());
                    dto.setUsos(e.getValue());
                    lista.add(dto);
                });

        return lista;
    }

    public List<UsuarioPopularDTO> usuarioPopular(){

        Map<Integer, Long> contador = new HashMap<>();

        List<Favorito> favoritos = favoritoRepository.findAll();

        for(Favorito f : favoritos){
            // Accedemos a la receta, luego al usuario propietario
            Integer idUsuario = f.getReceta().getUsuario().getIdUsuario();
            contador.put(idUsuario, contador.getOrDefault(idUsuario,0L) + 1L);
        }

        List<UsuarioPopularDTO> lista = new ArrayList<>();

        contador.entrySet().stream()
                .sorted((a,b)->Long.compare(b.getValue(), a.getValue()))
                .limit(5)
                .forEach(e->{
                    UsuarioPopularDTO dto = new UsuarioPopularDTO();
                    dto.setIdUsuario(e.getKey());
                    dto.setVecesGuardado(e.getValue());
                    lista.add(dto);
                });

        return lista;
    }
}
