package com.example.Smartchef.controladores;

import com.example.Smartchef.servicios.ListaCompraService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/listas-compra")
public class ListaCompraController {

    private ListaCompraService service;

    @PostMapping
    public ResponseEntity<?> crear(@RequestParam Integer idUsuario,
                                   @RequestParam Integer idReceta){
        return ResponseEntity.ok(service.generarLista(idUsuario, idReceta));
    }
}
